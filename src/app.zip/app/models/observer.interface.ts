export interface Observer {
    update(message: string): void;
  }
  