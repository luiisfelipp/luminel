const express = require('express');
const app = express();

// Habilitar el manejo de JSON
app.use(express.json());

// Variables para el estado del LED y el consumo
let ledState = "off";
let consumoAcumuladoWh = 0;

// Ruta para encender el LED
app.get('/light/led/on', (req, res) => {
  ledState = "on";
  console.log('LED encendido');
  res.status(200).send('LED encendido');
});

// Ruta para apagar el LED
app.get('/light/led/off', (req, res) => {
  ledState = "off";
  console.log('LED apagado');
  res.status(200).send('LED apagado');
});

// Ruta para recibir datos de consumo desde el Arduino
app.post('/consumo', (req, res) => {
  console.log('Cuerpo de la solicitud recibido:', req.body);

  // Validar que el cuerpo contiene el campo 'consumoAcumuladoWh'
  if (req.body && typeof req.body.consumoAcumuladoWh === 'number') {
    consumoAcumuladoWh = req.body.consumoAcumuladoWh;
    console.log(`Consumo recibido: ${consumoAcumuladoWh} Wh`);
    res.status(200).send('Consumo recibido correctamente');
  } else {
    console.log('Datos de consumo no válidos');
    res.status(400).send('Datos de consumo no válidos');
  }
});

// Ruta para consultar el consumo acumulado
app.get('/consumo', (req, res) => {
  res.status(200).json({ consumoAcumuladoWh });
});

// Iniciar el servidor en el puerto 3000
app.listen(3000, () => {
  console.log('Servidor iniciado en el puerto 3000');
});
