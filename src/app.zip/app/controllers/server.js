const express = require('express');
const app = express();


app.use(express.json());


// Ruta para encender todas las luces
app.get('/light/all/on', (req, res) => {
  console.log('Encendiendo todas las luces');
 
  // Aquí deberías agregar la lógica para encender las luces de tu hardware, por ejemplo:
  // (Supón que el hardware está respondiendo correctamente).
 
  // Luego, envía una respuesta al cliente:
  res.status(200).send('Todas las luces encendidas'); // Respuesta que confirma que las luces están encendidas
});


// Ruta para apagar todas las luces
app.get('/light/all/off', (req, res) => {
  console.log('Apagando todas las luces');
 
  // Lógica para apagar las luces de tu hardware
 
  // Enviar respuesta de confirmación
  res.status(200).send('Todas las luces apagadas');
});


// Inicia el servidor en el puerto 3000
app.listen(3000, () => {
  console.log('Servidor iniciado en el puerto 3000');
});
