import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-controllers',
  templateUrl: './controllers.page.html',
  styleUrls: ['./controllers.page.scss'],
})
export class ControllersPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
